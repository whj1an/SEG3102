# SEG3102 Lab 6 – REST Calculator Web Service

Spring Boot (Kotlin) REST API with OpenAPI documentation.

## Endpoints
| Operation | Request |
|---|---|
| Addition | `GET /calculator/add/{number1}/{number2}` |
| Subtraction | `GET /calculator/subtract/{number1}/{number2}` |
| Multiplication | `GET /calculator/multiply/{number1}/{number2}` |
| Division | `GET /calculator/divide/{number1}/{number2}` |

Invalid numbers and division by zero return `400 Bad Request`.

## Run
```
./gradlew bootRun        # Windows: gradlew.bat bootRun
```
Then try `http://localhost:8080/calculator/add/2/3`.

## OpenAPI documentation
- JSON: http://localhost:8080/v3/api-docs
- YAML: http://localhost:8080/v3/api-docs.yaml
- Swagger UI: http://localhost:8080/swagger-ui.html

## Tests
```
./gradlew test
```
