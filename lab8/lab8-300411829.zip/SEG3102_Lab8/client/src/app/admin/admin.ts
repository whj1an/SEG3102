import {Component, inject} from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {AuthorEntity, BookEntity} from '../books/model/bookEntity';
import {BooksService} from '../books/service/books-service';

function categoryValidator(control: FormControl<string>): { [s: string]: boolean } | null {
  const validCategories = ['Kids', 'Tech', 'Cook'];
  if (!validCategories.includes(control.value)) {
    return {invalidCategory: true};
  }
  return null;
}

@Component({
  selector: 'app-admin',
  templateUrl: './admin.html',
  styleUrls: ['./admin.css'],
  imports: [FormsModule, ReactiveFormsModule]
})
export class Admin {
  private builder: FormBuilder = inject(FormBuilder);
  private booksService: BooksService = inject(BooksService);
  bookForm = this.builder.group({
    bookNumber: ['', [Validators.required, Validators.pattern('[1-9]\\d{3}')]],
    category: ['', [Validators.required, categoryValidator]],
    title: ['', Validators.required],
    cost: ['', [Validators.required, Validators.pattern('\\d+(\\.\\d{1,2})?')] ],
    authors: this.builder.array([]),
    year: [''],
    description: ['']
  });

  get bookNumber(): AbstractControl {return <AbstractControl>this.bookForm.get('bookNumber'); }
  get category(): AbstractControl {return <AbstractControl>this.bookForm.get('category'); }
  get title(): AbstractControl {return <AbstractControl>this.bookForm.get('title'); }
  get cost(): AbstractControl {return <AbstractControl>this.bookForm.get('cost'); }
  get authors(): FormArray {
    return this.bookForm.get('authors') as FormArray;
  }

  onSubmit(): void {
    if (this.bookForm.valid) {
      const book = new BookEntity(0,
        Number(this.bookForm.value.bookNumber),
        <string>this.bookForm.value.category,
        <string>this.bookForm.value.title,
        Number(this.bookForm.value.cost),
        [],
        <string>this.bookForm.value.year,
        <string>this.bookForm.value.description);
      const authors = <AuthorEntity[]>this.bookForm.value.authors;
      this.booksService.addBook(book).subscribe(_ => {
        authors.forEach((author: AuthorEntity) => {
          this.booksService.addAuthor(Object.assign(author, {bookNumber: book.bookNumber}))
            .subscribe(_ => {
            });
        });
      });
      this.bookForm.reset();
      this.authors.clear();
    }
  }

  addAuthor(): void {
    this.authors.push(
      this.builder.group({
        firstName: [''],
        lastName: ['']
      })
    );
  }

  removeAuthor(i: number): void {
    this.authors.removeAt(i);
  }
}
