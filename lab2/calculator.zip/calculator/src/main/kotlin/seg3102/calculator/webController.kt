package seg3102.calculator

import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.ModelAttribute
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam

@Controller
class WebController {
    @ModelAttribute
    fun addAttributes(model: Model) {
        model.addAttribute("error", "")
        model.addAttribute("first", "")
        model.addAttribute("second", "")
        model.addAttribute("result", "")
    }

    @RequestMapping("/")
    fun home(): String {
        return "home"
    }

    @GetMapping(value = ["/calculate"])
    fun doCalculate(
        @RequestParam(value = "first", required = false) first: String,
        @RequestParam(value = "second", required = false) second: String,
        @RequestParam(value = "operation", required = false) operation: String,
        model: Model
    ): String {
        model.addAttribute("first", first)
        model.addAttribute("second", second)

        val firstVal: Double
        val secondVal: Double
        try {
            firstVal = first.toDouble()
            secondVal = second.toDouble()
        } catch (exp: NumberFormatException) {
            model.addAttribute("error", "NumberFormatError")
            return "home"
        }

        when (operation) {
            "+" -> model.addAttribute("result", String.format("%.2f", firstVal + secondVal))
            "-" -> model.addAttribute("result", String.format("%.2f", firstVal - secondVal))
            "*" -> model.addAttribute("result", String.format("%.2f", firstVal * secondVal))
            "/" ->
                if (secondVal == 0.0) {
                    model.addAttribute("error", "DivisionByZeroError")
                } else {
                    model.addAttribute("result", String.format("%.2f", firstVal / secondVal))
                }
            else -> model.addAttribute("error", "OperationFormatError")
        }
        return "home"
    }
}