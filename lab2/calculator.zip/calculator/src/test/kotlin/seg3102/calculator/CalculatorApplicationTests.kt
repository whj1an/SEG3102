package seg3102.calculator

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CalculatorApplicationTests {

	@Test
	fun contextLoads() {
	}

}
