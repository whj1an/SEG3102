package seg3102.calculator

import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders
import org.springframework.test.web.servlet.result.MockMvcResultMatchers

@WebMvcTest // <1>
class WebControllerTest {
    @Autowired // <2>
    lateinit var mockMvc: MockMvc

    @Test
    fun request_to_home() { // <4>
        mockMvc.perform(MockMvcRequestBuilders.get("/"))
            .andExpect(MockMvcResultMatchers.status().isOk) // <3>
            .andExpect(MockMvcResultMatchers.view().name("home"))
    }

    @Test
    fun addition() {
        mockMvc.perform(
            MockMvcRequestBuilders.get("/calculate")
                .param("first", "2")
                .param("second", "3")
                .param("operation", "+"))
            .andExpect(MockMvcResultMatchers.status().isOk)
            .andExpect(MockMvcResultMatchers.model().attribute("result", "5.00"))
            .andExpect(MockMvcResultMatchers.view().name("home"))
    }

    @Test
    fun subtraction() {
        mockMvc.perform(
            MockMvcRequestBuilders.get("/calculate")
                .param("first", "10")
                .param("second", "4")
                .param("operation", "-"))
            .andExpect(MockMvcResultMatchers.status().isOk)
            .andExpect(MockMvcResultMatchers.model().attribute("result", "6.00"))
    }

    @Test
    fun multiplication() {
        mockMvc.perform(
            MockMvcRequestBuilders.get("/calculate")
                .param("first", "3")
                .param("second", "4")
                .param("operation", "*"))
            .andExpect(MockMvcResultMatchers.status().isOk)
            .andExpect(MockMvcResultMatchers.model().attribute("result", "12.00"))
    }

    @Test
    fun division() {
        mockMvc.perform(
            MockMvcRequestBuilders.get("/calculate")
                .param("first", "9")
                .param("second", "3")
                .param("operation", "/"))
            .andExpect(MockMvcResultMatchers.status().isOk)
            .andExpect(MockMvcResultMatchers.model().attribute("result", "3.00"))
    }

    @Test
    fun division_by_zero() {
        mockMvc.perform(
            MockMvcRequestBuilders.get("/calculate")
                .param("first", "5")
                .param("second", "0")
                .param("operation", "/"))
            .andExpect(MockMvcResultMatchers.status().isOk)
            .andExpect(MockMvcResultMatchers.model().attribute("error", "DivisionByZeroError"))
    }

    @Test
    fun invalid_number() {
        mockMvc.perform(
            MockMvcRequestBuilders.get("/calculate")
                .param("first", "abc")
                .param("second", "3")
                .param("operation", "+"))
            .andExpect(MockMvcResultMatchers.status().isOk)
            .andExpect(MockMvcResultMatchers.model().attribute("error", "NumberFormatError"))
    }
}