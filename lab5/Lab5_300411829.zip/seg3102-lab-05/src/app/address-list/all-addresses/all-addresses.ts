import { Component, inject } from '@angular/core';
import { AsyncPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import { AddressEntry } from '../address-entry';
import { AddressDbService } from '../firestore/address-db-service';

@Component({
  selector: 'app-all-addresses',
  imports: [AsyncPipe, RouterLink],
  templateUrl: './all-addresses.html',
  styleUrl: './all-addresses.css',
})
export class AllAddresses {
  private store: AddressDbService = inject(AddressDbService);

  // Live stream of every entry stored in Firestore
  addresses$: Observable<AddressEntry[]> = this.store.getAddresses();
}
