import { Injectable, inject } from '@angular/core';
import {
  Firestore,
  collection,
  collectionData,
  addDoc,
  doc,
  setDoc,
  deleteDoc,
  DocumentReference,
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { AddressEntry } from '../address-entry';

@Injectable({
  providedIn: 'root',
})
export class AddressDbService {
  private firestore: Firestore = inject(Firestore);

  // All entries live in the Firestore collection abooks/user/addresses
  private get addresses() {
    return collection(this.firestore, 'abooks', 'user', 'addresses');
  }

  // Firestore rejects undefined fields and we don't store the id inside the document,
  // so build a plain object with only the data fields.
  private toData(address: AddressEntry) {
    return {
      firstName: address.firstName ?? '',
      lastName: address.lastName ?? '',
      phone: address.phone ?? '',
      email: address.email ?? '',
      notes: address.notes ?? '',
    };
  }

  getAddresses(): Observable<AddressEntry[]> {
    return collectionData(this.addresses, { idField: 'id' }) as Observable<AddressEntry[]>;
  }

  createAddress(address: AddressEntry): Promise<DocumentReference> {
    return addDoc(this.addresses, this.toData(address));
  }

  updateAddress(address: AddressEntry): Promise<void> {
    return setDoc(doc(this.addresses, address.id!), this.toData(address));
  }

  deleteAddress(addressId: string): Promise<void> {
    return deleteDoc(doc(this.addresses, addressId));
  }
}
