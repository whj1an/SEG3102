export const environment = {
  firebase: {
    apiKey: 'AIzaSyCvR5t0O2JsABLBMXGT5LWGK8PVFfuH610',
    authDomain: 'seg3102-lab5-w.firebaseapp.com',
    projectId: 'seg3102-lab5-w',
    storageBucket: 'seg3102-lab5-w.firebasestorage.app',
    messagingSenderId: '687413788614',
    appId: '1:687413788614:web:f90a5911611e213f1f7cc7',
    measurementId: 'G-233KW4HKTM',
  },
};
