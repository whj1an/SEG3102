import { Injectable } from '@angular/core';

// user information
export interface UserInfo {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
}

@Injectable({
  providedIn: 'root',
})
export class UserService {
  user: UserInfo | null = null;
}
