import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user-service';

@Component({
  selector: 'app-user-form',
  imports: [ReactiveFormsModule],
  templateUrl: './user-form.html',
  styleUrl: './user-form.css',
})
export class UserForm {
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private userService = inject(UserService);

  userForm = this.fb.nonNullable.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],


    phone: ['', Validators.pattern('[1-9]\\d{2}[1-9]\\d{6}')],
    email: ['', Validators.email],
  });

  get firstName() { return this.userForm.controls.firstName; }
  get lastName()  { return this.userForm.controls.lastName; }
  get phone()     { return this.userForm.controls.phone; }
  get email()     { return this.userForm.controls.email; }

  onSubmit(): void {
    if (this.userForm.invalid) {
      this.userForm.markAllAsTouched(); // Print all the errors if T
      return;
    }
    this.userService.user = this.userForm.getRawValue();
    this.router.navigate(['/result']);
  }
}