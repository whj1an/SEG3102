import { Component } from '@angular/core';
import { ShoppingItemForm } from './shopping-item-form/shopping-item-form';
import { ShoppingItem } from './shopping-item/shopping-item';

@Component({
  selector: 'app-shopping-list',
  imports: [ShoppingItemForm, ShoppingItem],
  templateUrl: './shopping-list.html',
  styleUrl: './shopping-list.css',
})
export class ShoppingList {
  items: string[] = [];

  addItem(name: string): void {
    this.items = [...this.items, name];
  }

  removeItem(index: number): void {
    this.items = this.items.filter((_, i) => i !== index);
  }
}
