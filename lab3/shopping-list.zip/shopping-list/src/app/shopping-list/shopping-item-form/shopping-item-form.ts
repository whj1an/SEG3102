import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-shopping-item-form',
  imports: [FormsModule],
  templateUrl: './shopping-item-form.html',
  styleUrl: './shopping-item-form.css',
})
export class ShoppingItemForm {
  @Output() itemAdded: EventEmitter<string> = new EventEmitter<string>();

  itemName = '';

  addItem(): void {
    const name = this.itemName.trim();
    if (!name) {
      return;
    }
    this.itemAdded.emit(name);
    this.itemName = '';
  }
}
