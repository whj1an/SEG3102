import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShoppingItemForm } from './shopping-item-form';

describe('ShoppingItemForm', () => {
  let component: ShoppingItemForm;
  let fixture: ComponentFixture<ShoppingItemForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShoppingItemForm],
    }).compileComponents();

    fixture = TestBed.createComponent(ShoppingItemForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
