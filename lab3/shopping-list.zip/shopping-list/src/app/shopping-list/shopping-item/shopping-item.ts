import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-shopping-item',
  imports: [],
  templateUrl: './shopping-item.html',
  styleUrl: './shopping-item.css',
})
export class ShoppingItem {
  @Input({ required: true }) name!: string;
  @Output() removeItem: EventEmitter<void> = new EventEmitter<void>();

  remove(): void {
    this.removeItem.emit();
  }
}
