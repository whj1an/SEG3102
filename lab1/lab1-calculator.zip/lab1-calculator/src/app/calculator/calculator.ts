import { Component } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.html',
  styleUrl: './calculator.css'
})
export class Calculator {
  result: number | string = '';

  calculate(first: string, second: string, operator: string) {
    const a = parseFloat(first);
    const b = parseFloat(second);

    if (isNaN(a) || isNaN(b)) {
      this.result = 'Please enter two numbers';
      return;
    }

    switch (operator) {
      case '+': this.result = a + b; break;
      case '-': this.result = a - b; break;
      case '*': this.result = a * b; break;
      case '/':
        this.result = b === 0 ? 'Cannot divide by zero' : a / b;
        break;
    }
  }
}