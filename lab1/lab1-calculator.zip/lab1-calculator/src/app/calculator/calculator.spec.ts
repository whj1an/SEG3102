import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Calculator } from './calculator';

describe('Calculator', () => {
  let component: Calculator;
  let fixture: ComponentFixture<Calculator>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Calculator],
    }).compileComponents();

    fixture = TestBed.createComponent(Calculator);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

    it('should add two numbers', () => {
    component.calculate('2', '3', '+');
    expect(component.result).toBe(5);
  });

  it('should subtract two numbers', () => {
    component.calculate('10', '4', '-');
    expect(component.result).toBe(6);
  });

  it('should multiply two numbers', () => {
    component.calculate('3', '4', '*');
    expect(component.result).toBe(12);
  });

  it('should divide two numbers', () => {
    component.calculate('9', '3', '/');
    expect(component.result).toBe(3);
  });

  it('should not divide by zero', () => {
    component.calculate('5', '0', '/');
    expect(component.result).toBe('Cannot divide by zero');
  });
});
